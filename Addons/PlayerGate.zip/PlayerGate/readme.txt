CharacterGate by Xander
Legitimately a Solid but I use empty code to make it not interact with Projectiles XD (since they're actually just empty code blocks, the included license is WTFPL)

-Installation instructions-
1. Load the data.win for the project you want this to be used in in UTMT.
2. Once loaded, navigate to the Scripts/ResourceRepackers Tab and select "ImportGML.csx"
3. Navigate to the inclosed "Code" Folder and select it.
4. The script will ask you if you wish to automatically link imported code. Clicking Yes will prompt the app to create a new "oCharacterGate" Object if you do not have one.
5. If you do not have the oCharacterGate object, click yes on both options. If you do have the oCharacterGate Object and do not wish to automatically link code, click "No" and it will simply add it to the codebase.

-Additional Setup Instructions-
Make sure this is set up as a solid entity, and as a child to oSolid.

-Usage-
Prevents the character from moving through, but allows Projectiles. I recommend using with a Metal Grate texture to show that yeah, you couldn't fit through that.

Merry Christmas, from Xander
